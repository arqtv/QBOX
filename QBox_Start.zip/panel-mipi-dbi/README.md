# panel-mipi-dbi

Tool to make firmware files for the Linux display driver panel-mipi-dbi.

See wiki for more information: https://github.com/notro/panel-mipi-dbi/wiki
