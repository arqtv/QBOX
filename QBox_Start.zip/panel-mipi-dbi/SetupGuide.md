**QBox Setup Guide**

1. Burn a Raspberry Pi OS Image to an SD Card
   1. Download the Raspberry Pi Image Maker from the official source
   2. Use the Image Maker to install Bookworm 64/32 bit onto an SD card
   3. Test the OS on the SD card on your Raspberry Pi
2. Create the firmware file required for your LCD
   1. The MIPI-DBI-SPI Overlay needed to use the LCD with your Raspberry Pi requires a firware file to provide the driver with the correct boot sequence for your LCD. In this example, we are going to use the ST7789v LCD.
   2. Once you have found the correct .txt containing the boot sequence for your LCD, you can compile it into a .bin file with the following command (N.B. You will need to set up a Python Virtual Environment to use the mipi-dbi-cmd).

      ```text
      ./mipi-dbi-cmd mipi-dbi-st7789v.bin ST7789.txt
      ```
      N.B. It is important that you name your bin file something unique so it does not match names with any other drivers on the system. For example, if it is named st7789v.bin, it may clash with the fbtft_st7789v driver.
      
   3. Now you have a .bin file for your LCD, you will need to move it to the Raspberry Pi. One way to do this is via SCP:

      ```text
      sudo scp mipi-dbi-st7789.bin viota@[YOUR RASPBERRY PI SSH ADDRESS]:/home/viota/
      ```
   4. Now, on your Raspberry Pi, you can copy the new firmware file into the /lib/firmware/ folder (you will need sudo to do this):

      ```text
      sudo cp /home/viota/st7789.bin /lib/firmware/
      ```
   5. Once the firmware file is in the correct place, you can modify your config.txt to the following (you will need to use sudo to modify the file):

      ```text
      dtparam=i2c_arm=on
      #dtparam=i2s=on
      dtparam=spi=on
      
      [all]
      
      dtoverlay=mipi-dbi-spi,spi0-0,speed=32000000
      dtparam=compatible=mipi-dbi-st7789v\0panel-mipi-dbi-spi
      dtparam=width=320,height=240
      dtparam=reset-gpio=27,dc-gpio=25,backlight-gpio=18
      ```
   6. Now, after a reboot, you should see the CLI appear on the LCD. To run the desktop environment, you can run:
      ```text
      wayfire
      ```
      The desktop environment should be up and running!